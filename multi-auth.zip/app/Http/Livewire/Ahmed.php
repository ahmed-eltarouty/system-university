<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Ahmed extends Component
{
    public function render()
    {
        return view('livewire.ahmed')->layout('livewire.layouts.admin');
    }
}
